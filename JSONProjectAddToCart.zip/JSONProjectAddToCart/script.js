document.querySelector("#saveData").addEventListener("submit", (e) => {
  e.preventDefault();

  const productCategory = document.querySelector("#category").value;
  const productName = document.querySelector("#productName").value;
  const productPrice = document.querySelector("#productPrice").value;
  const productQuantity = document.querySelector("#quantity").value;
  const productDescription = document.querySelector("#description").value;
  const imageUrl = document.querySelector("#imageUrl").value;
  // const id =

  const prprice = productPrice * productQuantity;
  console.log(prprice);

  // console.log(productCategory);
  if (productCategory == "") {
    var Category_error = (document.querySelector("#Category_error").innerHTML =
      "please select product category");
  } else {
    var Category_error = (document.querySelector("#Category_error").innerHTML =
      "");
  }
  if (productName == "") {
    var prName_error = (document.querySelector("#prName_error").innerHTML =
      "please select product Name");
  } else {
    var prName_error = (document.querySelector("#prName_error").innerHTML = "");
  }

  if (productPrice == "") {
    var prPrice_error = (document.querySelector("#prPrice_error").innerHTML =
      "please select product Name");
  } else {
    var prPrice_error = (document.querySelector("#prPrice_error").innerHTML =
      "");
  }

  if (productQuantity == "") {
    var prQulity_error = (document.querySelector("#prQulity_error").innerHTML =
      "please select product Name");
  } else {
    var prQulity_error = (document.querySelector("#prQulity_error").innerHTML =
      "");
  }

  if (productDescription == "") {
    var prdes_error = (document.querySelector("#prdes_error").innerHTML =
      "please select product Name");
  } else {
    var prdes_error = (document.querySelector("#prdes_error").innerHTML = "");
  }

  if (imageUrl == "") {
    var image_error = (document.querySelector("#image_error").innerHTML =
      "please select product Name");
  } else {
    var image_error = (document.querySelector("#image_error").innerHTML = "");
  }

  if (
    Category_error == "" &&
    prName_error == "" &&
    prPrice_error == "" &&
    prQulity_error == "" &&
    prdes_error == "" &&
    image_error == ""
  ) {
    const arr = JSON.parse(localStorage.getItem("userList")) || [];
    // console.log(arr);

    const id = arr.length + 1;
    const product = {
      id,
      productCategory,
      productName,
      productPrice,
      productQuantity,
      productDescription,
      imageUrl,
      prprice,
    };

    arr.push(product);
    localStorage.setItem("userList", JSON.stringify(arr));
    // window.location.href = "cardStore.html";

    show();
  }
});

function show() {
  const userList = JSON.parse(localStorage.getItem("userList")) || [];
  let result = "";
  userList.forEach((element, index) => {
    result += `
  <div class="col-4 mb-4">
      <div class="card">
          <img src="${element.imageUrl}" class="card-img-top p-2  " height = "400" alt="Product Image">
      <button class="cancelbtn" onclick="cancelCart(${index})"><i class="fa-solid fa-xmark"></i></button>
          <div class="card-body">
              <h5 class="card-title">${element.productName}</h5>
              <p class="card-text  prdDes">${element.productDescription}</p>
              <p class="card-text"> <b> Price:</b>  ${element.productPrice}</p>
              <p class="card-text"><b> Quantity: </b> ${element.productQuantity}</p>
              <p class="card-text"><b>Totalprice: </b>  ${element.prprice}</p>
          </div>
          <button class="btn btn-warning" onclick ="AddToCart(${element.id})" >ADD TO CART</button>
      </div>
  </div>`;
  });
  document.querySelector("#valueStore").innerHTML = result;
}
show();
function AddToCart(id){
  const product = JSON.parse(localStorage.getItem('userList'))
  const cart = JSON.parse(localStorage.getItem('cartList')) || [];

  // product exist or not according to id
  const existProduct=product.find((item)=>{
    return item.id===id
  })
  ///cart exist or not according to id
  const existCart=cart.find((item)=>{
    return item.id===id
  })
  console.log(existCart)

  if(existCart){
    existCart.count+=1
  }else{
    cart.push({...existProduct,count:1})
  }
  localStorage.setItem('cartList',JSON.stringify(cart))
  window.location.href = "cardStore.html"
}

function cancelCart(userid) {
  // alert("cancel")
  if(confirm("Do you want to delete this Item?")){
    const user = JSON.parse(localStorage.getItem("userList"));
  user.splice(userid, 1);
  localStorage.setItem("userList", JSON.stringify(user));
  show();
  }
  
}

